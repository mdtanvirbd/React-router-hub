function App() {
  return (
    <div className="p-6 text-center">
      <h1 className="text-4xl font-bold text-blue-600">Vite + React + Tailwind + DaisyUI</h1>
      <button className="btn btn-primary mt-4">DaisyUI Button</button>
    </div>
  );
}

export default App;